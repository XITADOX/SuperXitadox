
import pyautogui
import keyboard
import time
from PIL import ImageGrab

# Configuration
TRIGGER_KEY = "insert"
TRIGGER_DELAY = 0.05  # seconds
ENEMY_COLORS = [(255, 255, 0), (0, 0, 255)]  # yellow, blue
HEAD_COLOR = (0, 0, 0)  # black

def get_pixel_color():
    screen = ImageGrab.grab()
    x, y = screen.size[0] // 2, screen.size[1] // 2
    return screen.getpixel((x, y))

def fire():
    pyautogui.mouseDown()
    time.sleep(0.01)
    pyautogui.mouseUp()

def main():
    print("SuperXitadox Trigger Bot running... Press INSERT to toggle.")
    triggered = False
    while True:
        if keyboard.is_pressed(TRIGGER_KEY):
            triggered = not triggered
            print("Trigger Bot:", "ON" if triggered else "OFF")
            time.sleep(0.5)

        if triggered:
            color = get_pixel_color()
            if color in ENEMY_COLORS or color == HEAD_COLOR:
                fire()
        time.sleep(TRIGGER_DELAY)

if __name__ == "__main__":
    main()
